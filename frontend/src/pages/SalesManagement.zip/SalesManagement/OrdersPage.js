import React, { useState } from "react";

const OrdersPage = () => {
    // Sample orders state
    const [orders, setOrders] = useState([
        { id: 1001, customer: "John Doe", date: "2025-01-15", status: "Completed", total: "$200.00" },
        { id: 1002, customer: "Jane Smith", date: "2025-01-16", status: "Pending", total: "$150.00" }
    ]);

    // New Order form state
    const [isCreatingOrder, setIsCreatingOrder] = useState(false);
    const [newOrder, setNewOrder] = useState({
        customer: "",
        date: "",
        status: "Pending",
        total: ""
    });

    // Handle "Create Order" button click
    const handleCreateOrder = () => {
        setIsCreatingOrder(true);
    };

    // Handle form input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewOrder({
            ...newOrder,
            [name]: value
        });
    };

    // Handle form submission to create a new order
    const handleSubmitOrder = (e) => {
        e.preventDefault();
        const newOrderId = orders.length + 1001; // New order ID
        const newOrderData = {
            ...newOrder,
            id: newOrderId,
            total: `$${parseFloat(newOrder.total).toFixed(2)}` // Format total
        };
        setOrders([...orders, newOrderData]); // Add new order to the list
        setIsCreatingOrder(false); // Close the form after submission
        setNewOrder({ customer: "", date: "", status: "Pending", total: "" }); // Reset the form
    };

    return (
        <div className="orders-container">
            <h1 className="orders-header">Orders Management</h1>
            <p>View and manage orders placed in the store and online.</p>

            {/* Create Order Button */}
            <button className="create-order-btn" onClick={handleCreateOrder}>Create Order</button>

            {/* New Order Form */}
            {isCreatingOrder && (
                <form onSubmit={handleSubmitOrder} className="create-order-form">
                    <h3>Create New Order</h3>
                    <div>
                        <label>Customer Name:</label>
                        <input
                            type="text"
                            name="customer"
                            value={newOrder.customer}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Order Date:</label>
                        <input
                            type="date"
                            name="date"
                            value={newOrder.date}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <div>
                        <label>Status:</label>
                        <select
                            name="status"
                            value={newOrder.status}
                            onChange={handleInputChange}
                            required
                        >
                            <option value="Pending">Pending</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div>
                        <label>Total Amount:</label>
                        <input
                            type="number"
                            name="total"
                            value={newOrder.total}
                            onChange={handleInputChange}
                            required
                        />
                    </div>
                    <button type="submit">Submit Order</button>
                    <button type="button" onClick={() => setIsCreatingOrder(false)}>Cancel</button>
                </form>
            )}

            {/* Orders Table */}
            <table className="orders-table">
                <thead>
                    <tr>
                        <th>Order Number</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map((order) => (
                        <tr key={order.id}>
                            <td>#{order.id}</td>
                            <td>{order.customer}</td>
                            <td>{order.date}</td>
                            <td className={`order-status ${order.status.toLowerCase()}`}>{order.status}</td>
                            <td>{order.total}</td>
                            <td>
                                <button className="view-btn" onClick={() => alert(`Viewing details for Order #${order.id}`)}>View</button>
                                <button className="cancel-btn" onClick={() => alert(`Cancelling Order #${order.id}`)}>Cancel</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <style>
                {`
                .orders-container {
                    padding: 20px;
                    font-family: Arial, sans-serif;
                }

                .orders-header {
                    font-size: 28px;
                    color: #343a40;
                    font-weight: bold;
                    margin-bottom: 20px;
                }

                .orders-table {
                    width: 100%;
                    border-collapse: collapse;
                    background-color: #fff;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                }

                .orders-table th, .orders-table td {
                    padding: 12px;
                    border: 1px solid #dcdcdc;
                    text-align: left;
                }

                .orders-table th {
                    background-color: #f1f1f1;
                    font-weight: bold;
                }

                .order-status {
                    padding: 5px 10px;
                    border-radius: 5px;
                    color: white;
                    text-align: center;
                    display: inline-block;
                }

                .order-status.pending {
                    background-color: #ffc107;
                }

                .order-status.completed {
                    background-color: #28a745;
                }

                .order-status.cancelled {
                    background-color: #dc3545;
                }

                .view-btn, .cancel-btn {
                    padding: 8px 12px;
                    margin-right: 5px;
                    border: none;
                    cursor: pointer;
                    font-weight: bold;
                    border-radius: 4px;
                }

                .view-btn {
                    background-color: #007bff;
                    color: white;
                }

                .view-btn:hover {
                    background-color: #0056b3;
                }

                .cancel-btn {
                    background-color: #dc3545;
                    color: white;
                }

                .cancel-btn:hover {
                    background-color: #a71d2a;
                }

                .create-order-btn {
                    padding: 10px 20px;
                    background-color: #28a745;
                    color: white;
                    font-weight: bold;
                    border: none;
                    border-radius: 4px;
                    margin-bottom: 20px;
                    cursor: pointer;
                }

                .create-order-btn:hover {
                    background-color: #218838;
                }

                .create-order-form {
                    margin-bottom: 20px;
                    background-color: #f9f9f9;
                    padding: 20px;
                    border-radius: 5px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    width: 100%;
                    max-width: 600px;
                }

                .create-order-form h3 {
                    font-size: 24px;
                    margin-bottom: 20px;
                }

                .create-order-form div {
                    margin-bottom: 10px;
                }

                .create-order-form label {
                    display: block;
                    margin-bottom: 5px;
                }

                .create-order-form input,
                .create-order-form select {
                    width: 100%;
                    padding: 8px;
                    border-radius: 4px;
                    border: 1px solid #ccc;
                }

                .create-order-form button {
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: white;
                    font-weight: bold;
                    border: none;
                    border-radius: 4px;
                    margin-top: 10px;
                    cursor: pointer;
                }

                .create-order-form button[type="button"] {
                    background-color: #dc3545;
                }

                /* Responsive Design */
                @media screen and (max-width: 768px) {
                    .orders-table {
                        display: block;
                        overflow-x: auto;
                    }

                    .orders-table th, .orders-table td {
                        white-space: nowrap;
                    }
                }
                `}
            </style>
        </div>
    );
};

export default OrdersPage;
