import React, { useState } from "react";

const ReturnsAndRefunds = () => {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [exchangeItems, setExchangeItems] = useState([]); // To track items for exchange
  const [refundReceipt, setRefundReceipt] = useState(null); // To store refund receipt data
  const orders = [
    { id: "#140", date: "Tue Jan 23, 2024", total: "£179.55", channel: "POS", status: "Partial Refunded" },
    { id: "#139", date: "Tue Jan 9, 2024", total: "£47.25", channel: "POS", status: "Completed" },
    { id: "#138", date: "Tue Jan 9, 2024", total: "£18.90", channel: "POS", status: "Completed" },
    { id: "#137", date: "Tue Jan 9, 2024", total: "£18.90", channel: "POS", status: "Completed" },
    { id: "#136", date: "Tue Jan 9, 2024", total: "£18.90", channel: "POS", status: "Completed" },
    { id: "#131", date: "Tue Jan 9, 2024", total: "£56.70", channel: "POS", status: "Refunded" },
    { id: "E-130", date: "Tue Jan 9, 2024", total: "£280.00", channel: "POS", status: "Completed" },
  ];

  const handleOrderClick = (order) => {
    setSelectedOrder(order);
  };

  const handlePrintInvoice = () => {
    window.print(); // Opens the browser print dialog
  };

  const handleSendEmail = () => {
    alert("Order email has been sent successfully!"); // Simulate email sending
  };

  const handleReturn = () => {
    alert("Refund successfully processed with cash!");
  };
  const handleExchange = () => {
    if (!selectedOrder) {
      alert("Please select an order first.");
      return;
    }
  
    // Simulate exchanging items (you can replace this with actual logic)
    const exchangedItems = [
      { name: "New Sunglasses", price: "£100.00" },
      { name: "New Beanie", price: "£20.00" },
    ];
  
    setExchangeItems(exchangedItems);
    alert("Exchange processed successfully!");
  };
  const handlePrintRefundReceipt = () => {
    if (!selectedOrder) {
      alert("Please select an order first.");
      return;
    }
  
    // Simulate refund receipt data
    const receiptData = {
      orderId: selectedOrder.id,
      refundedAmount: "£37.80",
      refundDate: new Date().toLocaleString(),
      items: [
        { name: "Sunglasses", price: "£90.00" },
        { name: "Beanie", price: "£18.00" },
      ],
    };
  
    setRefundReceipt(receiptData);
    window.print(); // Open the browser print dialog
  };
  return (
    <div className="container">
      {/* Top Navigation */}
      <div class="nav-tabs">
  <a href="/ReturnsAndRefunds" class="tab active">Sale History</a>
  <a href="/ReturnRefundHoldSale" class="tab">Hold Sale</a>
  <a href="/ReturnRefundOfflineOrders" class="tab">Offline Sale/Orders</a>
</div>

 
      {/* Order Table */}
      <div className="order-container">
        <table className="order-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Order Date</th>
              <th>Order Total</th>
              <th>Channel</th>
              <th>Order Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} onClick={() => handleOrderClick(order)}>
                <td>{order.id}</td>
                <td>{order.date}</td>
                <td>{order.total}</td>
                <td>{order.channel}</td>
                <td className={order.status === "Refunded" ? "status refunded" : order.status === "Partial Refunded" ? "status partial" : "status completed"}>
                  {order.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Order Details Section */}
    {selectedOrder && (
      <div className="order-details">
        <h3>Order ID {selectedOrder.id}</h3>
        <p><strong>Kate Doe</strong></p>
        <p><small>{selectedOrder.date} | 08:11 AM</small></p>

        <div className="order-summary">
          <p>Sunglasses - <strong>£90.00</strong></p>
          <p>Beanie - <strong>£18.00</strong></p>
        </div>

        <hr />

        {/* Display Exchange Items */}
        {exchangeItems.length > 0 && (
          <div className="exchange-items">
            <h4>Exchanged Items:</h4>
            {exchangeItems.map((item, index) => (
              <p key={index}>{item.name} - <strong>{item.price}</strong></p>
            ))}
          </div>
        )}

        {/* Display Refund Receipt */}
        {refundReceipt && (
          <div className="refund-receipt">
            <h4>Refund Receipt:</h4>
            <p>Order ID: <strong>{refundReceipt.orderId}</strong></p>
            <p>Refunded Amount: <strong>{refundReceipt.refundedAmount}</strong></p>
            <p>Refund Date: <strong>{refundReceipt.refundDate}</strong></p>
            <h5>Refunded Items:</h5>
            {refundReceipt.items.map((item, index) => (
              <p key={index}>{item.name} - <strong>{item.price}</strong></p>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="actions">
          <button className="print" onClick={handlePrintInvoice}>Print Invoice</button>
          <button className="email" onClick={handleSendEmail}>Send Order Email</button>
          <button className="return" onClick={handleReturn}>Return</button>
          <button className="exchange" onClick={handleExchange}>Exchange</button>
          <button className="refund" onClick={handlePrintRefundReceipt}>Print Refund Receipt</button>
        </div>
      </div>
    )}
      {/* Styling */}
      <style>
        {`
        .container {
 
  padding: 20px;
}

/* Navigation Tabs Container */
.nav-tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
}

/* Styling for Tabs */
.tab {
  background: #f6b88f;
  text-decoration: none;
  padding: 12px 20px;
  border-radius: 5px;
  font-weight: bold;
  color: black;
  transition: background 0.3s ease, color 0.3s ease;
}

/* Active Tab */
.tab.active {
  background: #ff914d;
  color: white;
}

/* Hover Effect */
.tab:hover {
  background: #ff914d;
  color: white;
}


/* Order Table */
.order-container {
  background: white;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
  overflow-x: auto;
}

.order-table {
  width: 100%;
  border-collapse: collapse;
}

.order-table th, .order-table td {
  padding: 10px;
  text-align: left;
}

.order-table tr:hover {
  background: #f5f5f5;
  cursor: pointer;
}

.status {
  padding: 5px 10px;
  border-radius: 15px;
  font-weight: bold;
}

.completed {
  background: #d4f8d4;
  color: #008000;
}

.refunded {
  background: #ffcccc;
  color: #d9534f;
}

.partial {
  background: #dad2f8;
  color: #5a4fcf;
}

/* Order Details Section */
.order-details {
  background: white;
  padding: 20px;
  margin-top: 20px;
  border-radius: 10px;
  box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
}

.order-summary p {
  margin: 5px 0;
}

.order-status {
  font-weight: bold;
  color: #ff914d;
}

.refunded-amount {
  font-weight: bold;
  color: #d9534f;
}

/* Buttons */
.actions button {
  display: block;
  width: 100%;
  margin: 5px 0;
  padding: 10px;
  border: none;
  font-weight: bold;
  cursor: pointer;
  border-radius: 5px;
}

.print { background: #FF5722; color: white; }
.email { background: #FF5722; color: white; }
.return { background: #FF5722; color: white; }
.exchange { background: #FF5722; color: white; }
.refund { background: #FF5722; color: white; }

.exchange-items, .refund-receipt {
  margin-top: 15px;
  padding: 10px;
  background: #f9f9f9;
  border-radius: 5px;
}

.exchange-items h4, .refund-receipt h4 {
  margin-bottom: 10px;
  color: #ff914d;
}

.refund-receipt h5 {
  margin-top: 10px;
  color: #d9534f;
}
`}
      </style>
    </div>
  );
};

export default ReturnsAndRefunds;
