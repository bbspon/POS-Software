import React, { useState, useEffect } from "react";

// Helper function to get promotions from localStorage
const getPromotionsFromLocalStorage = () => {
  const promotions = localStorage.getItem("promotions");
  return promotions ? JSON.parse(promotions) : [];
};

const PromotionsPage = () => {
  const [promotions, setPromotions] = useState(getPromotionsFromLocalStorage()); // Load from localStorage
  const [selectedPromotion, setSelectedPromotion] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    type: " ", // Default type
    name: "",
    description: "",
    startDate: "",
    endDate: "",
    status: "",
  });
  const [searchTerm, setSearchTerm] = useState("");

  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle promotion form submission (Add/Edit)
  const handleFormSubmit = (e) => {
    e.preventDefault();
    const newPromotion = { id: Date.now(), ...formData }; // Use Date.now() for unique ID

    if (isEditing) {
      const updatedPromotions = promotions.map((promo) =>
        promo.id === selectedPromotion.id ? newPromotion : promo
      );
      setPromotions(updatedPromotions);
      localStorage.setItem("promotions", JSON.stringify(updatedPromotions));
    } else {
      const updatedPromotions = [...promotions, newPromotion];
      setPromotions(updatedPromotions);
      localStorage.setItem("promotions", JSON.stringify(updatedPromotions));
    }

    // Clear form and reset states
    setFormData({
      type: "",
      name: "",
      description: "",
      startDate: "",
      endDate: "",
      status: "",
    });
    setIsEditing(false);
  };

  // Handle select promotion for editing
  const handleSelectPromotion = (promotion) => {
    setSelectedPromotion(promotion);
    setFormData(promotion); // Populate the form with selected promotion data
    setIsEditing(true); // Set editing mode to true
  };

  // Handle delete promotion
  const handleDeletePromotion = (id) => {
    const updatedPromotions = promotions.filter((promotion) => promotion.id !== id);
    setPromotions(updatedPromotions);
    localStorage.setItem("promotions", JSON.stringify(updatedPromotions));
  };

  // Filter promotions by search term
  const filteredPromotions = promotions.filter((promotion) =>
    promotion.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="promotion-page">
      {/* Search Bar */}
      <div className="promotion-search">
        <input
          type="text"
          placeholder="Search Promotions"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Promotion List */}
      <div className="promotion-list">
        <h2>Promotions List</h2>
        <table className="promotion-table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Name</th>
              <th>Description</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPromotions.map((promotion) => (
              <tr key={promotion.id}>
                <td>{promotion.type}</td>
                <td>{promotion.name}</td>
                <td>{promotion.description}</td>
                <td>{promotion.status}</td>
                <td>
                  <button className="edit-btn" onClick={() => handleSelectPromotion(promotion)}>
                    Edit
                  </button>
                  <button className="delete-btn" onClick={() => handleDeletePromotion(promotion.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Promotion Form */}
      <div className="promotion-form">
        <h2>{isEditing ? "Edit Promotion" : "Add New Promotion"}</h2>
        <form onSubmit={handleFormSubmit}>
          <div className="form-group">
            <label>Promotion Type:</label>
            <select
              name="type"
              value={formData.type}
              onChange={handleInputChange}
              required
            >
              <option value="Festival">Festival Promotion</option>
              <option value="Product">Product Promotion</option>
            </select>
          </div>
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Description:</label>
            <input
              type="text"
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Start Date:</label>
            <input
              type="date"
              name="startDate"
              value={formData.startDate}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>End Date:</label>
            <input
              type="date"
              name="endDate"
              value={formData.endDate}
              onChange={handleInputChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Status:</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleInputChange}
              required
            >
              <option value="">Select Status</option>
              <option value="Active">Active</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Expired">Expired</option>
            </select>
          </div>
          <button type="submit">{isEditing ? "Update" : "Add"} New Promotion</button>
        </form>
      </div>

      {/* Styles */}
      <style>
        {`
        .promotion-page {
          display: flex;
          justify-content: space-between;
          padding: 20px;
        }

        .promotion-list, .promotion-form {
          width: 45%;
        }

        .promotion-table {
          width: 100%;
          border-collapse: collapse;
        }

        .promotion-table th, .promotion-table td {
          padding: 10px;
          border: 1px solid #ddd;
        }

        .promotion-table th {
          background-color: #f4f4f4;
        }

        .promotion-form input, .promotion-form select {
          width: 100%;
          padding: 8px;
          margin-bottom: 10px;
          border: 1px solid #ddd;
          border-radius: 5px;
        }

        .promotion-table td button {
          padding: 6px 12px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          margin-left: 5px;
        }

        .edit-btn {
          background-color: #3498db;
          color: white;
        }

        .edit-btn:hover {
          background-color: #2980b9;
        }

        .delete-btn {
          background-color: #e74c3c;
          color: white;
        }

        .delete-btn:hover {
          background-color: #c0392b;
        }
        `}
      </style>
    </div>
  );
};

export default PromotionsPage;
