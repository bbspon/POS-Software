import React, { useState, useEffect } from 'react';

const ProductsPage = () => {
    const [products, setProducts] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredProducts, setFilteredProducts] = useState([]);

    useEffect(() => {
        // Mock product data (replace this with an API call if needed)
        setProducts([
            { id: 1, name: 'Tomato', stock: 20, status: 'In Stock', category: 'Vegetables', price: 1.5, salePrice: 1.0, thumbnail: 'https://via.placeholder.com/50' },
            { id: 2, name: 'Apple', stock: 0, status: 'Out of Stock', category: 'Fruits', price: 2.0, salePrice: 1.8, thumbnail: 'https://via.placeholder.com/50' },
            { id: 3, name: 'Bread', stock: 10, status: 'In Stock', category: 'Bakery', price: 3.0, salePrice: 2.5, thumbnail: 'https://via.placeholder.com/50' },
            { id: 4, name: 'Milk', stock: 5, status: 'Low Stock', category: 'Dairy', price: 1.2, salePrice: 1.1, thumbnail: 'https://via.placeholder.com/50' },
        ]);
    }, []);

    useEffect(() => {
        setFilteredProducts(
            products.filter((product) =>
                product.name.toLowerCase().includes(searchTerm.toLowerCase())
            )
        );
    }, [searchTerm, products]);

    return (
        <div className="products-page-container">
            <h2>Products - Store Management</h2>
            <input
                type="text"
                placeholder="Search Products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-bar"
            />

            <table className="products-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Regular Price</th>
                        <th>Sale Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredProducts.map((product) => (
                        <tr key={product.id}>
                            <td className="product-info">
                                <img src={product.thumbnail} alt={product.name} />
                                <span>{product.name}</span>
                            </td>
                            <td>
                                <input
                                    type="number"
                                    defaultValue={product.stock}
                                    className="stock-input"
                                />
                            </td>
                            <td className={`status ${product.status.toLowerCase().replace(/\s/g, '-')}`}>{product.status}</td>
                            <td>{product.category}</td>
                            <td>$
                                
                                {product.price}</td>
                            <td>${product.price.toFixed(2)}</td>
                            <td>${product.salePrice.toFixed(2)}</td>
                            <td>
                                <button className="edit-btn">Edit</button>
                                <button className="update-btn">Update Stock</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <style>
                {`
                body {
    font-family: 'Arial, sans-serif';
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.products-page-container {
    width: 95%;
    max-width: 1300px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

h2 {
    font-size: 28px;
    margin-bottom: 20px;
    color: #343a40;
}

.search-bar {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 2px solid #dcdcdc;
    border-radius: 8px;
    margin-bottom: 20px;
}

.products-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

.products-table th, .products-table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.products-table th {
    background-color: #f1f1f1;
    font-weight: bold;
    text-align: center;
}

.product-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.product-info img {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 5px;
}

.status {
    font-weight: bold;
    padding: 5px 10px;
    border-radius: 5px;
    text-align: center;
}

.status.in-stock {
    background-color: #d4edda;
    color: #155724;
}

.status.out-of-stock {
    background-color: #f8d7da;
    color: #721c24;
}

.status.low-stock {
    background-color: #fff3cd;
    color: #856404;
}

.stock-input {
    width: 60px;
    padding: 5px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.edit-btn, .update-btn {
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin-right: 5px;
}

.edit-btn {
    background-color: #ffc107;
    color: #343a40;
}

.update-btn {
    background-color: #007bff;
    color: white;
}

.edit-btn:hover {
    background-color: #e0a800;
}

.update-btn:hover {
    background-color: #0056b3;
}

`}
            </style>
        </div>
    );
};

export default ProductsPage;
